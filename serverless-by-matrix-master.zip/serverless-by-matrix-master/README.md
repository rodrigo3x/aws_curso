# serverless-by-matrix
Infrastructure as code (IaC) with AWS Serverless Framework.
